# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 0.1.0 (2023-01-20)

### Features

- **widget-addi:** insert new Addi widget and payment slot by method ([#849](https://github.com/ecomplus/storefront/issues/849)) ([42fee84](https://github.com/ecomplus/storefront/commit/42fee8446490954a8c7a37f9207bb19f70119b5e))

# Change Log
